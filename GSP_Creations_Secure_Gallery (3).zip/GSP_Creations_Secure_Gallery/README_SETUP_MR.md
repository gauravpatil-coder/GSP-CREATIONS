# GSP Creations — सुरक्षित Public Gallery सेटअप

## महत्त्वाचे
हा प्रकल्प Firebase जोडण्यासाठी तयार केलेला starter आहे. Firebase प्रकल्प तयार करून खालील placeholders बदलून rules publish करेपर्यंत वेबसाइट live/secure झाली असे समजू नका.

## 1. Firebase तयार करा
1. https://console.firebase.google.com/ उघडा आणि नवीन project तयार करा.
2. Project settings → Your apps → Web app तयार करा. तिथला `firebaseConfig` `index.html` मध्ये पेस्ट करा. `apiKey`, `authDomain`, `projectId`, `storageBucket`, `appId` बदला. Service-account/private keys कधीही HTML मध्ये टाकू नका.
3. Authentication → Sign-in method मध्ये Email/Password enable करा.
4. Authentication → Users मध्ये owner साठी email/password user तयार करा. त्याच्या User UID ची प्रत घ्या.
5. `index.html` मधील `OWNER_UID = 'PASTE_OWNER_AUTH_UID'` येथे UID पेस्ट करा.
6. `firestore.rules` आणि `storage.rules` या दोन्ही फाइलमधील `PASTE_OWNER_AUTH_UID` जागी तोच UID लिहा.
7. Firestore Database तयार करा आणि `firestore.rules` Rules tab मध्ये publish करा. Storage तयार करून `storage.rules` publish करा.
8. Firebase Storage साठी billing/plan आवश्यकता Console मध्ये तपासा; प्रकल्पाच्या धोरणांनुसार bucket setup पूर्ण करा.
9. वेबसाइट HTTPS hosting वर deploy करा (Firebase Hosting किंवा दुसरी static host). `index.html` थेट `file://` ने उघडण्यापेक्षा hosting वापरा.

## 2. सुरक्षा
- Gallery चे read access public आहे; Upload/Delete फक्त निर्दिष्ट UID असलेल्या login ला मिळते.
- Client-side लपवलेले बटण ही सुरक्षा नाही; Firestore/Storage Rules मुख्य नियंत्रण आहेत.
- Firebase Console मध्ये owner UID अचूक भरल्याशिवाय upload/delete चालणार नाही.
- Firebase Console मध्ये billing alerts/usage limits ठेवा आणि owner account ला मजबूत unique password व 2FA उपलब्ध असल्यास वापरा.
- Firebase config browser मध्ये दिसणे expected आहे; service account key, passwords, private secrets browser code मध्ये ठेवू नका.

## 3. WhatsApp गोपनीयता
तुझा नंबर page वर मजकूर म्हणून दाखवलेला नाही; Order बटण `wa.me` link उघडते. मात्र त्या link च्या URL मधून WhatsApp नंबर शोधता येऊ शकतो. ग्राहकांना नंबर तांत्रिकदृष्ट्या अजिबात न दिसणे आवश्यक असेल, तर backend-mediated contact/order service वापरावी लागेल; साध्या WhatsApp click-to-chat link ने हे लपवता येत नाही.

## 4. सध्याच्या मर्यादा
- Firebase config आणि owner UID तुझ्या Console मधून भरलेले नसल्याने हा archive अजून deployed नाही.
- जुनी localStorage gallery वेगळ्या browser मध्ये आपोआप migrate होत नाही; जुने फोटो पुन्हा owner login ने upload कर.
- Delete operation आधी Firestore document delete करते; Storage delete अयशस्वी झाल्यास orphaned file manually साफ करावी लागू शकते.
